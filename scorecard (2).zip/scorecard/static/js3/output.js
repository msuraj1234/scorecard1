var range_el = document.querySelector('input[type=range]'), 
    base_sel = '.js input[type=range]', 
    thumb_sel = ['::-webkit-slider-thumb', ' /deep/ #thumb'], 
    a = ':after'
    style_el = document.createElement('style');

document.body.appendChild(style_el);

range_el.addEventListener('input', function() {
  style_el.textContent = base_sel + thumb_sel[0] + a + ',' + 
    base_sel + thumb_sel[1] + a + '{content:"' + this.value + '°"}';
  console.log(style_el.textContent);
}, false);
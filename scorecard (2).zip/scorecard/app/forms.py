from dataclasses import fields
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from .models import applicationScore


class applicationScoreForm(forms.ModelForm):
    name = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    age = forms.CharField(max_length=30,widget=forms.TextInput(attrs={'class': "input--style-4"}))
    city = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    zipcode = forms.CharField(max_length=30,widget=forms.TextInput(attrs={'class': "input--style-4"}))
    familysize = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    housesize = forms.CharField(max_length=30,widget=forms.TextInput(attrs={'class': "input--style-4"}))
    income = forms.CharField(max_length=30,widget=forms.TextInput(attrs={'class': "input--style-4"}))
    appliance = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    creditscore = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    preService = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    missedPayments = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    contractLength = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    couponUser = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    greenEnergyUser = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    planPreference = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "input--style-4"}))
    class Meta:
        model = applicationScore
        fields = '__all__'


class PrettyAuthenticationForm(AuthenticationForm):
    class Meta:
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control text-lowercase'}),
            'password': forms.TextInput(attrs={'class': 'form-control text-lowercase'})
        }

class UserForm(UserCreationForm):
    username = forms.CharField(max_length=30, widget=forms.TextInput(attrs={'class': "form-control text-lowercase"}))
    email = forms.EmailField(required=True,widget=forms.TextInput(attrs={'class': "form-control text-lowercase"}))
    password1 = forms.CharField(max_length=20,widget=forms.TextInput(attrs={'class': "form-control text-lowercase",'type': "password"}))
    password2 = forms.CharField(label='Confirm Password', widget=forms.TextInput(attrs={'class': "form-control text-lowercase",'type': "password"}))
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']
        labels = {'email':'Email'}
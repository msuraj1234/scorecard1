from django.shortcuts import render, HttpResponseRedirect
from .forms import UserForm
from .forms import PrettyAuthenticationForm
from .forms import applicationScoreForm
from django.contrib.auth import authenticate, login, logout
from .models import applicationScore
from django.contrib.auth.models import User
import plotly.graph_objects as go
import numpy as np


'''# Create your views here.
def signup(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/login')
        else:
            return render(request,'index.html',{'form':form})
    else:
        form = UserForm()
        return render(request,'index.html',{'form':form})
        '''

    

valid_user1 = None
uname1 = None
def login_user(request):
    global valid_user1, uname1
    if request.method == 'POST':
        print(request.method)
        form1 = PrettyAuthenticationForm(request = request,data =  request.POST)
        if form1.is_valid():
            print('validated')
            uname = form1.cleaned_data['username']
            upass = form1.cleaned_data['password']
            user = authenticate(username = uname, password = upass)
            valid_user = User.objects.get(username = uname)
            valid_user1 = valid_user.username
            uname = uname1
            # valid_profile = applicationScore.objects.get(id = valid_user.id)
            if user is not None:
                print('Logged In')
                login(request, user)
            return HttpResponseRedirect('/app_form')
        else:
            return render(request,'login.html',{'form1':form1})
    else:
        form1 = PrettyAuthenticationForm()
        return render(request,'login.html',{'form1':form1})


def application_form(request):
    global valid_user1, uname1
    print('Hi re aaja',valid_user1, uname1)
    if request.method == 'POST':
        print(request.method)
        username = request.POST['username']
        name = request.POST['name']
        age = request.POST['age']
        city = request.POST['city']
        zipcode = request.POST['zipcode']
        housesize = request.POST['housesize']
        familysize = request.POST['familysize']
        appliance = request.POST['appliance']
        creditscore = request.POST['creditscore']
        preService = request.POST['preService']
        missedPayments = request.POST['missedPayments']
        contractLength = request.POST['contractLength']
        couponUser = request.POST['couponUser']
        greenEnergyUser = request.POST['greenEnergyUser']
        income = request.POST['income']
        planPreference = request.POST['planPreference']
        data = applicationScore(username=username,name=name,city=city,age=age,zipcode=zipcode,housesize=housesize,
        familysize=familysize,appliance=appliance,creditscore=creditscore,preService=preService,missedPayments=missedPayments,
        contractLength=contractLength,couponUser=couponUser,greenEnergyUser=greenEnergyUser,income=income,
        planPreference=planPreference)
        print('Valid_user:',valid_user1, 'user:', username)
        if valid_user1 == username:
            data.save()
            query = applicationScore.objects.get(username = username)
            print(query.name,'age',query.age)
            chart = gauge1(query)
            chart2 = gauge2(query)
            bachart = barchart1(query)
            return render(request,'output.html',{'data':query,'gauge':chart,'gauge1':chart2,'barchart':bachart})
        else:
            return render(request,'app_form.html')
        
    else:
        form2 = applicationScoreForm()
        return render(request,'app_form.html')

def gauge1():
    fig = go.Figure(go.Indicator(
    mode = "gauge+number",
    value = 250,
    domain = {'x': [0, 1], 'y': [0, 1]},
    title = {'text': ""}))

    fig.update_layout(
    autosize=False,
    width=500,
    height=250,
)

    chart = fig.to_html()
    # return render(request,'output.html',{'chart':chart})
    return chart
    
def gauge2():
    fig = go.Figure(go.Indicator(
    mode = "gauge+number",
    value = 300,
    domain = {'x': [0, 1], 'y': [0, 1]},
    title = {'text': ""}))

    fig.update_layout(
    autosize=False,
    width=500,
    height=250,
)


    chart1 = fig.to_html()
    # return render(request,'output.html',{'chart':chart})
    return chart1

# def slider():
    # return red, green, blue

def barchart1():
    fig = go.Figure(go.Bar(
            x=[20, 14, 23],
            y=['SMS', 'Email', 'Call'],
            orientation='h'))
    
    fig.update_layout(
    autosize=False,
    width=300,
    height=100,
    )

    barchart = fig.to_html()
    # return render(request,'output2.html',{'barchart':barchart})
    return barchart

def charts(request):
    gauge = gauge1()
    gauge3 = gauge2()
    barchart = barchart1()
    # slider1 = slider()
    return render(request,'output.html',{'barchart':barchart,'gauge':gauge,'gauge1':gauge3})

def home2(request):
    return render(request,'output2.html',{})   

def home(request):
    return render(request,'output.html',{})  

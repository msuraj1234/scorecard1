from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class applicationScore(models.Model):
    username = models.CharField(max_length=30)
    name = models.CharField(max_length=30)
    age = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    zipcode = models.CharField(max_length=30)
    familysize = models.CharField(max_length=30)
    housesize = models.CharField(max_length=50)
    income = models.CharField(max_length=30)
    appliance = models.CharField(max_length=30)
    creditscore = models.CharField(max_length=30)
    preService = models.CharField(max_length=50)
    missedPayments = models.CharField(max_length=50)
    contractLength = models.CharField(max_length=30)
    couponUser = models.CharField(max_length=30)
    greenEnergyUser = models.CharField(max_length=30)
    planPreference = models.CharField(max_length=30)
